# ADR 0001: Choose Hydra + DVC
Rationale and tradeoffs.
