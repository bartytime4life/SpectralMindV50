# ADR 0002: Physics-informed losses
