# ADR 0003: CI/Docker/Kaggle CUDA parity
