#!/usr/bin/env bash
set -euo pipefail
python -m spectramind submit --config-name submit
