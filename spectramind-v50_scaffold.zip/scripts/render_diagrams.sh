#!/usr/bin/env bash
set -euo pipefail
echo "(placeholder) render Mermaid diagrams"
