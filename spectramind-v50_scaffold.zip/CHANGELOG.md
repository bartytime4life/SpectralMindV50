## 0.1.0
- Initial scaffold with CI, DVC, Kaggle-ready configs.
