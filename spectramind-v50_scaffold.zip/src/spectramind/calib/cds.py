class Cds:
    def run(self, x):
        return x
