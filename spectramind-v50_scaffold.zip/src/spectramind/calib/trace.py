class Trace:
    def run(self, x):
        return x
