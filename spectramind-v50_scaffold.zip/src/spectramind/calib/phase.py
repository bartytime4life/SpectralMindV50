class Phase:
    def run(self, x):
        return x
