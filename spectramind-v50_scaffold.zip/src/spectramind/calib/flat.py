class Flat:
    def run(self, x):
        return x
