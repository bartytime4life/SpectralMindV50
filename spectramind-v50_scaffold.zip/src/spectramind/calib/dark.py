class Dark:
    def run(self, x):
        return x
