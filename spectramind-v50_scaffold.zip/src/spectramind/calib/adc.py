class Adc:
    def run(self, x):
        return x
