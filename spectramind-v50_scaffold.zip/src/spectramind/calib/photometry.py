class Photometry:
    def run(self, x):
        return x
