def collate(batch): return batch
