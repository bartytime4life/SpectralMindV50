def zscore(x): return (x - x.mean())/(x.std()+1e-8)
