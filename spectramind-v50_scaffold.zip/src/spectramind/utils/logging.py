from rich.console import Console
console = Console()
def info(msg: str): console.log(msg)
