# Contributing
1. `make dev` to setup, `pre-commit` must pass.
2. Write tests; keep interfaces stable; document configs.
3. Use ADRs for non-trivial decisions in `ADR/`.
