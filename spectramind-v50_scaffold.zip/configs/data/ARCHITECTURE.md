Defines ingestion, calibration, preprocessing, and splits for SpectraMind V50.
